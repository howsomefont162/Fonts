Copyright (c) 2019 by Dmitry Rastvortsev. Ordered by Projector, Dmytro Bulanov Creative Bu:ro and Banda Agency for Kyiv city identification. Long live Free Ukraine!

Freeware. Font free for commercial and non-commercial use. Must not be decompiled. NoDerivates.

http://rastvor.com.ua